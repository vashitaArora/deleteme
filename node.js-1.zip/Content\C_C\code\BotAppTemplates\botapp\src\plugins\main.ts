export class Main {
    public printFromMain(session: any): void {
        session.send("Printing from main");
    }
	
	/*-----------------------------------------------------------------------------
A simple echo bot for the Microsoft Bot Framework. 
-----------------------------------------------------------------------------*/

  public printFromMain1(session: any): void {
        session.send("Printing from main");
    }
	
	  public printFromMain2(session: any): void {
        session.send("Printing from main");
    }
	
	
	  public printFromMain3(session: any): void {
        session.send("Printing from main");
    }
	
	  public printFromMain4(session: any): void {
        session.send("Printing from main");
    }

    //public runCommand()
}