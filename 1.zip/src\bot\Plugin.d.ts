export enum CommandType {
    standardCommand,
    userDefinedCommand
}

export interface Command {
    name: string,
    type: CommandType,
    paramsInString: string, //params json in string
    params: any //params in json
}

export interface Plugin {
    name: string,
    path: string,
    commandList: Command[]
}