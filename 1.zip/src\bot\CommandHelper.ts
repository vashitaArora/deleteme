import { Plugin, PluginsHelper } from './PluginsHelper';
import { join } from 'path';
const { lstatSync, readdirSync } = require('fs')

export enum CommandType {
    standardCommand,
    userDefinedCommand
}

export interface Command {
    name: string,
    type: CommandType,
    paramsInString: string, //params json in string
    params: any //params in json
}

export class CommandHelper {
    private plugins: Plugin[];
    private commandList: Command[] = [];

    public constructor(pluginsHelper: PluginsHelper) {
        this.plugins = pluginsHelper.getPluginList();
    }

    public initializePluginSpecificCommandList(): void {
        this.plugins.forEach((plugin: Plugin) => {
            const pluginPath = plugin.path;

            const stdCmdDir = join(pluginPath, "stdcommands");
            let isDirectory = lstatSync(stdCmdDir).isDirectory();
            if (isDirectory) {
                // Initialize the plugin

                readdirSync(stdCmdDir).map((name: any) => {
                    this.commandList.push({
                        name: name,
                        type: CommandType.standardCommand,
                        paramsInString: "",
                        params: ""
                    });
                });
            }

            const userCmdDir = join(pluginPath, "usercommands");
            isDirectory = lstatSync(stdCmdDir).isDirectory();
            if (isDirectory) {
                // Initialize the plugin

                readdirSync(userCmdDir).map((name: any) => {
                    this.commandList.push({
                        name: name,
                        type: CommandType.userDefinedCommand,
                        paramsInString: "",
                        params: ""
                    });
                });
            }
        });

        
    }
}
