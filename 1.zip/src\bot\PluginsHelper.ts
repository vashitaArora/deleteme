const { lstatSync, readdirSync } = require('fs')
const { join } = require('path')

export interface Plugin {
    name: string,
    path: string
}

export class PluginsHelper {
    private pluginList: Plugin[] = [];

    public initializePlugins(): void {
        var source = join(__dirname, '../plugins');
        const isDirectory = lstatSync(source).isDirectory();
        if (isDirectory) {
            // Initialize the plugin

            readdirSync(source).map((name: any) => {
                this.pluginList.push({
                    name: name,
                    // Windows only for now
                    path: join(source, name)
                });
            });
        }
    }

    public initializeSupportedCommands(): void {
        
    }

    public getPluginList(): Plugin[] {
        return this.pluginList;
    }

    public printPluginList(session: any): void {
        this.pluginList.forEach((plugin: Plugin) => {
            session.send("name: " + plugin.name + " path: " + plugin.path);
        })
    }
}