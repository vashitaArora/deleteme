var restify = require('restify');
var builder = require('botbuilder');
var botbuilder_azure = require("botbuilder-azure");
const { createOAuthPrompt } = require('botbuilder-prompts');

export class BotConfig {
    private server: any;
    private connector: any;
    private bot: any;

    public static setupServer(): any {
        // Setup Restify Server
        var server = restify.createServer();
        server.listen(process.env.port || process.env.PORT || 3978, function () {
        console.log('%s listening to %s', server.name, server.url); 
        });
        
        // Create chat connector for communicating with the Bot Framework Service
        var connector = new builder.ChatConnector({
            appId: process.env.MicrosoftAppId,
            appPassword: process.env.MicrosoftAppPassword,
            openIdMetadata: process.env.BotOpenIdMetadata
        });

        // Listen for messages from users 
        server.post('/api/messages', connector.listen());
        
        // Create our oauthPrompt
        const oauthPrompt = createOAuthPrompt({
            text: 'Please sign in',
            title: 'Sign in',
            connectionName: connector.connectionName,
        });

        console.log("Created oauth Prompt");
        /*
        server.post('/api/messages', () => {
            oauthPrompt.prompt();
        });
        */
        return connector;
    }

    public static setupTableStorage(): any {
        // No storage used currently to be used as:
        //bot.set('storage', tableStorage);

        var tableName = 'botdata';
        var azureTableClient = new botbuilder_azure.AzureTableClient(tableName, process.env['AzureWebJobsStorage']);
        var tableStorage = new botbuilder_azure.AzureBotStorage({ gzipData: false }, azureTableClient);
        return tableStorage;
    }
}