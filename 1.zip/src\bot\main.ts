/*-----------------------------------------------------------------------------
A simple echo bot for the Microsoft Bot Framework. 
-----------------------------------------------------------------------------*/

var builder = require('botbuilder');

import { Main } from '../plugins/vsts/main';
import { BotConfig } from './BotConfig';
import { PluginsHelper } from './PluginsHelper';

var connector = BotConfig.setupServer();
var pluginsHelper = new PluginsHelper();
pluginsHelper.initializePlugins();

// Create your bot with a function to receive messages from the user
var bot = new builder.UniversalBot(connector);

bot.dialog('/', function (session: any) {
    let vstsMain = new Main();
    vstsMain.printFromMain(session);
    
    pluginsHelper.printPluginList(session);
});